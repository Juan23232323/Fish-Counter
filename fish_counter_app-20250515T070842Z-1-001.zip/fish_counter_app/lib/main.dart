import 'dart:math';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final cameras = await availableCameras();
  runApp(FishCounterApp(cameras));
}

class FishCounterApp extends StatelessWidget {
  final List<CameraDescription> cameras;

  FishCounterApp(this.cameras);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: FishCounterScreen(cameras),
    );
  }
}

class FishCounterScreen extends StatefulWidget {
  final List<CameraDescription> cameras;
  FishCounterScreen(this.cameras);

  @override
  _FishCounterScreenState createState() => _FishCounterScreenState();
}

class _FishCounterScreenState extends State<FishCounterScreen> {
  CameraController? controller;
  bool isDetecting = false;
  int fishCount = 0;
  bool trainingMode = false;

  @override
  void initState() {
    super.initState();
    initializeCamera();
  }

  Future<void> initializeCamera() async {
    controller = CameraController(widget.cameras[0], ResolutionPreset.medium);
    await controller!.initialize();
    setState(() {});
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fish Counter"),
        actions: [
          Switch(
            value: trainingMode,
            onChanged: (value) {
              setState(() {
                trainingMode = value;
              });
            },
          )
        ],
      ),
      body: controller != null && controller!.value.isInitialized
          ? Stack(
              children: [
                CameraPreview(controller!),
                Positioned(
                  top: 20,
                  left: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Detection Speed: 10 FPS",
                        style: TextStyle(color: Colors.yellow, fontSize: 18),
                      ),
                      Text(
                        "Count: $fishCount",
                        style: TextStyle(
                            color: Colors.yellow,
                            fontSize: 24,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                if (!trainingMode)
                  Positioned(
                    bottom: 30,
                    left: 30,
                    right: 30,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () => setState(() => fishCount++),
                          child: Text('+'),
                        ),
                        ElevatedButton(
                          onPressed: () =>
                              setState(() => fishCount = max(0, fishCount - 1)),
                          child: Text('-'),
                        ),
                        ElevatedButton(
                          onPressed: () => setState(() => fishCount = 0),
                          child: Text('Reset'),
                        ),
                      ],
                    ),
                  ),
              ],
            )
          : Center(child: CircularProgressIndicator()),
    );
  }
}